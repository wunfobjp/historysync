// background.js - Service Worker
importScripts('common.js', 'webdav-client.js', 'history-sync.js');

// 监听来自 popup 或 options 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'incrementalBackup') {
    self.HistorySync.incrementalBackup().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'fullDownload') {
    self.HistorySync.fullDownload().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'fullBackup') {
    self.HistorySync.fullBackup().then(result => sendResponse(result));
    return true;
  }
  return false;
});