// common.js - 全局工具函数和常量
self.Common = (function() {
  // 存储键名常量
  const STORAGE_KEYS = {
    WEBDAV_URL: 'webdav_url',
    WEBDAV_USER: 'webdav_user',
    WEBDAV_PASS: 'webdav_pass',
    LAST_SYNC_TIME: 'last_sync_time',
    BACKUP_FILE: 'history_backup.json',
    // 新增：自动同步配置
    AUTO_SYNC_ENABLED: 'auto_sync_enabled',
    AUTO_SYNC_INTERVAL: 'auto_sync_interval'   // 分钟数，如 60, 360, 720, 1440, 10080
  };

  // 获取存储值
  async function getStorage(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }

  // 设置存储值
  async function setStorage(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  // 显示通知
  function showNotification(title, message, type = 'basic') {
    chrome.notifications.create({
      type: type,
      iconUrl: 'icons/icon48.png',
      title: title,
      message: message,
      priority: 2
    });
  }

  return {
    STORAGE_KEYS,
    getStorage,
    setStorage,
    showNotification
  };
})();