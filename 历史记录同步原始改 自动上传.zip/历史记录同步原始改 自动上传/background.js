// background.js - Service Worker（支持自动同步）
importScripts('common.js', 'webdav-client.js', 'history-sync.js');

const { STORAGE_KEYS, getStorage, setStorage, showNotification } = self.Common;
const ALARM_NAME = 'autoSyncAlarm';

// 根据间隔分钟数，转换为 Alarms API 的 periodInMinutes
function getAlarmPeriod(intervalMinutes) {
  if (!intervalMinutes || intervalMinutes <= 0) return null;
  // Chrome Alarms 最小周期为 0.0167 小时（1分钟），我们直接使用分钟数
  return intervalMinutes;
}

// 创建或更新定时任务
async function updateAutoSyncAlarm() {
  const enabled = await getStorage(STORAGE_KEYS.AUTO_SYNC_ENABLED);
  const intervalMinutes = await getStorage(STORAGE_KEYS.AUTO_SYNC_INTERVAL);
  
  // 先清除已有的 alarm
  await chrome.alarms.clear(ALARM_NAME);
  
  if (enabled && intervalMinutes && intervalMinutes > 0) {
    const period = getAlarmPeriod(intervalMinutes);
    if (period) {
      chrome.alarms.create(ALARM_NAME, { periodInMinutes: period });
      console.log(`自动同步已启用，间隔 ${intervalMinutes} 分钟`);
      // 可选：通知用户自动同步已启动（静默，不打扰）
    }
  } else {
    console.log('自动同步已禁用');
  }
}

// 执行自动同步（合并上传）
async function performAutoSync() {
  try {
    console.log('执行自动同步（合并上传）...');
    const result = await self.HistorySync.incrementalBackup();
    if (result.success) {
      console.log(`自动同步完成: ${result.message}`);
      // 静默同步，不弹通知（避免频繁打扰），可改为只在失败时通知
      // 如果需要通知，可取消注释下一行
      // showNotification('自动同步', result.message, 'basic');
    } else {
      console.error(`自动同步失败: ${result.message}`);
      showNotification('自动同步失败', result.message, 'basic');
    }
  } catch (err) {
    console.error('自动同步异常', err);
    showNotification('自动同步异常', err.message, 'basic');
  }
}

// 监听 alarm 事件
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_NAME) {
    // 检查 WebDAV 配置是否完整
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) {
      console.warn('自动同步跳过：WebDAV 配置不完整');
      return;
    }
    await performAutoSync();
  }
});

// 监听存储变化，当自动同步配置改变时更新 alarm
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes[STORAGE_KEYS.AUTO_SYNC_ENABLED] || changes[STORAGE_KEYS.AUTO_SYNC_INTERVAL]) {
      updateAutoSyncAlarm();
    }
  }
});

// 扩展安装或启动时，初始化定时任务
chrome.runtime.onStartup.addListener(() => {
  updateAutoSyncAlarm();
});

chrome.runtime.onInstalled.addListener(() => {
  updateAutoSyncAlarm();
});

// 原有的消息监听（保持不变）
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'incrementalBackup') {
    self.HistorySync.incrementalBackup().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'fullDownload') {
    self.HistorySync.fullDownload().then(result => sendResponse(result));
    return true;
  } else if (message.action === 'fullBackup') {
    self.HistorySync.fullBackup().then(result => sendResponse(result));
    return true;
  }
  return false;
});