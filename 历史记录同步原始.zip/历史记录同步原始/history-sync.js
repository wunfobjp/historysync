self.HistorySync = (function() {
  const { STORAGE_KEYS, getStorage, setStorage, showNotification } = self.Common;
  const WebDAVClient = self.WebDAVClient;

  async function getWebDAVClient() {
    const url = await getStorage(STORAGE_KEYS.WEBDAV_URL);
    const user = await getStorage(STORAGE_KEYS.WEBDAV_USER);
    const pass = await getStorage(STORAGE_KEYS.WEBDAV_PASS);
    if (!url || !user || !pass) {
      throw new Error('请先配置WebDAV参数');
    }
    return new WebDAVClient(url, user, pass);
  }

  async function getRemoteBackup(client) {
    const content = await client.getFile(`/${STORAGE_KEYS.BACKUP_FILE}`);
    if (!content) return [];
    try {
      const data = JSON.parse(content);
      return Array.isArray(data) ? data : [];
    } catch (e) {
      return [];
    }
  }

  async function putRemoteBackup(client, records) {
    const jsonStr = JSON.stringify(records, null, 2);
    return await client.putFile(`/${STORAGE_KEYS.BACKUP_FILE}`, jsonStr);
  }

  function getHistorySince(startTime) {
    return new Promise((resolve) => {
      chrome.history.search({
        text: '',
        startTime: startTime || 0,
        maxResults: 10000
      }, (results) => {
        const items = results.map(item => ({
          url: item.url,
          title: item.title || '',
          lastVisitTime: item.lastVisitTime,
          visitCount: item.visitCount,
          typedCount: item.typedCount || 0,
          id: item.id
        }));
        resolve(items);
      });
    });
  }

  function mergeHistoryRecords(existing, incoming) {
    const map = new Map();
    for (const rec of existing) {
      const key = `${rec.url}|${rec.lastVisitTime}`;
      map.set(key, rec);
    }
    for (const rec of incoming) {
      const key = `${rec.url}|${rec.lastVisitTime}`;
      if (!map.has(key)) map.set(key, rec);
    }
    const merged = Array.from(map.values());
    merged.sort((a, b) => a.lastVisitTime - b.lastVisitTime);
    return merged;
  }

  async function incrementalBackup() {  // 合并上传
    try {
      const lastSync = await getStorage(STORAGE_KEYS.LAST_SYNC_TIME) || 0;
      const newHistory = await getHistorySince(lastSync);
      if (newHistory.length === 0) {
        showNotification('合并上传', '没有新的历史记录');
        return { success: true, message: '无新增记录' };
      }
      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);
      const merged = mergeHistoryRecords(remoteRecords, newHistory);
      await putRemoteBackup(client, merged);
      const maxTime = Math.max(...newHistory.map(r => r.lastVisitTime), Date.now());
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);
      showNotification('合并上传完成', `新增 ${newHistory.length} 条`);
      return { success: true, message: `已合并上传 ${newHistory.length} 条` };
    } catch (err) {
      showNotification('合并上传失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function fullDownload() {
    try {
      const client = await getWebDAVClient();
      const remoteRecords = await getRemoteBackup(client);
      if (remoteRecords.length === 0) {
        showNotification('全量下载', '远程无数据');
        return { success: false, message: '无远程数据' };
      }
      let addedCount = 0;
      for (const record of remoteRecords) {
        await new Promise((resolve) => {
          chrome.history.addUrl({
            url: record.url,
            title: record.title,
            visitTime: record.lastVisitTime,
            transition: 'typed'
          }, () => {
            if (!chrome.runtime.lastError) addedCount++;
            resolve();
          });
        });
      }
      const maxRemoteTime = Math.max(...remoteRecords.map(r => r.lastVisitTime), 0);
      const currentLastSync = await getStorage(STORAGE_KEYS.LAST_SYNC_TIME) || 0;
      if (maxRemoteTime > currentLastSync) {
        await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxRemoteTime);
      }
      showNotification('全量下载完成', `导入 ${addedCount} 条`);
      return { success: true, message: `导入了 ${addedCount} 条` };
    } catch (err) {
      showNotification('全量下载失败', err.message);
      return { success: false, message: err.message };
    }
  }

  async function fullBackup() {  // 全量上传
    try {
      const allHistory = await getHistorySince(0);
      const client = await getWebDAVClient();
      await putRemoteBackup(client, allHistory);
      const maxTime = Math.max(...allHistory.map(r => r.lastVisitTime), Date.now());
      await setStorage(STORAGE_KEYS.LAST_SYNC_TIME, maxTime);
      showNotification('全量上传完成', `备份 ${allHistory.length} 条`);
      return { success: true, message: `全量上传 ${allHistory.length} 条` };
    } catch (err) {
      showNotification('全量上传失败', err.message);
      return { success: false, message: err.message };
    }
  }

  return {
    incrementalBackup,
    fullDownload,
    fullBackup
  };
})();