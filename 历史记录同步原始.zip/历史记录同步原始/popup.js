const btnInc = document.getElementById('btnIncremental');
const btnDown = document.getElementById('btnFullDownload');
const btnFull = document.getElementById('btnFullBackup');
const btnSettings = document.getElementById('btnSettings');
const statusDiv = document.getElementById('status');

function setStatus(text, isError = false) {
  statusDiv.textContent = text;
  statusDiv.style.color = isError ? '#d32f2f' : '#2e7d32';
  setTimeout(() => {
    if (statusDiv.textContent === text) {
      statusDiv.style.color = '#555';
      statusDiv.textContent = '就绪';
    }
  }, 3000);
}

btnInc.addEventListener('click', async () => {
  setStatus('合并上传中...');
  const result = await chrome.runtime.sendMessage({ action: 'incrementalBackup' });
  setStatus(result.message, !result.success);
});

btnDown.addEventListener('click', async () => {
  setStatus('全量下载中...');
  const result = await chrome.runtime.sendMessage({ action: 'fullDownload' });
  setStatus(result.message, !result.success);
});

btnFull.addEventListener('click', async () => {
  setStatus('全量上传中...');
  const result = await chrome.runtime.sendMessage({ action: 'fullBackup' });
  setStatus(result.message, !result.success);
});

btnSettings.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});