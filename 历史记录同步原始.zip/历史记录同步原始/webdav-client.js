// webdav-client.js - 增强版，支持MKCOL和更好的路径处理
self.WebDAVClient = class WebDAVClient {
  constructor(baseUrl, username, password) {
    // 移除末尾多余的斜杠，统一处理
    this.baseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
    this.username = username;
    this.password = password;
  }

  // 生成 Basic 认证头
  _getAuthHeader() {
    const credentials = btoa(`${this.username}:${this.password}`);
    return `Basic ${credentials}`;
  }

  // 通用请求方法
  async _request(path, method, body = null, headers = {}) {
    // 规范化路径：确保 path 以 / 开头，然后拼接到 baseUrl
    const normalizedPath = path.startsWith('/') ? path : '/' + path;
    const url = `${this.baseUrl}${normalizedPath}`;
    const options = {
      method,
      headers: {
        'Authorization': this._getAuthHeader(),
        ...headers
      }
    };
    if (body) {
      options.body = body;
    }
    const response = await fetch(url, options);
    // 404 不算错误，表示文件或目录不存在
    if (!response.ok && response.status !== 404) {
      throw new Error(`WebDAV请求失败: ${response.status} ${response.statusText}`);
    }
    return response;
  }

  // 获取文件内容（文本），不存在返回 null
  async getFile(remotePath) {
    const response = await this._request(remotePath, 'GET');
    if (response.status === 404) {
      return null;
    }
    return await response.text();
  }

  // 上传文件（覆盖），支持自动创建目录（MKCOL）
  async putFile(remotePath, content, contentType = 'application/json') {
    try {
      const response = await this._request(remotePath, 'PUT', content, {
        'Content-Type': contentType
      });
      if (response.ok) return true;
      // 如果状态是 409 (Conflict)，通常表示中间目录不存在，尝试创建目录
      if (response.status === 409) {
        const lastSlash = remotePath.lastIndexOf('/');
        if (lastSlash > 0) {
          const dirPath = remotePath.substring(0, lastSlash);
          await this._createDirectory(dirPath);
          // 重试上传
          return this.putFile(remotePath, content, contentType);
        }
      }
      return false;
    } catch (e) {
      // 如果错误是因为目录不存在，尝试创建目录后重试
      if (e.message.includes('409') || e.message.includes('Conflict')) {
        const lastSlash = remotePath.lastIndexOf('/');
        if (lastSlash > 0) {
          const dirPath = remotePath.substring(0, lastSlash);
          await this._createDirectory(dirPath);
          return this.putFile(remotePath, content, contentType);
        }
      }
      throw e;
    }
  }

  // 创建目录（MKCOL）
  async _createDirectory(dirPath) {
    const response = await this._request(dirPath, 'MKCOL');
    // 如果目录已存在（405 或 409）也算成功
    if (response.status === 200 || response.status === 201 || response.status === 405 || response.status === 409) {
      return true;
    }
    if (!response.ok) {
      throw new Error(`创建目录失败: ${response.status}`);
    }
    return true;
  }

  // 测试连接：尝试 GET 备份文件，允许 404（表示认证通过但文件尚不存在）
  async testConnection(backupFileName = 'history_backup.json') {
    try {
      const response = await this._request(backupFileName, 'GET');
      // 200 或 404 都说明服务器可达且认证正确
      return response.status === 200 || response.status === 404;
    } catch (e) {
      console.error('连接测试失败', e);
      return false;
    }
  }
};